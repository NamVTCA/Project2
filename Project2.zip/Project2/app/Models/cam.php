<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class cam extends Model
{
     protected $fillable = [
        'name',
        'stream_url'
    ];
}
