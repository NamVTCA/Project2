<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/ClassroomsIndex.css')); ?>">
<div class="classes-container">
    <div class="back-button">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Quay về
        </a>
    </div>
    <div class="header">
        <h1>Quản lý lớp học</h1>
        <a href="<?php echo e(route('classrooms.create')); ?>" class="btn-add">Thêm lớp học mới</a>
        <a href="<?php echo e(route('facility_management.index')); ?>" class="btn btn-primary">Quản lý cơ sở vật chất</a>
    </div>
    <div class="class-card highlight">
        <div class="classes-grid">
            <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="class-card">
                    <div class="class-info">
                        <h3><?php echo e($class->name); ?></h3>
                        <p>Giáo viên: <?php echo e($class->user ? $class->user->name : 'N/A'); ?></p>
                        <p>Trạng thái: <?php echo e($class->status == 1 ? 'Hoạt động' : 'Không hoạt động'); ?></p>
                        <h5>Cơ sở vật chất:</h5>
                        <?php if($class->facilities->isEmpty()): ?>
                            <p>Không có cơ sở vật chất nào</p>
                        <?php else: ?>
                            <ul>
                                <?php $__currentLoopData = $class->facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        Cơ sở vật chất: <?php echo e($facility->name ?? 'N/A'); ?> -  
                                        Số lượng: <?php echo e($facility->quantity); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                    <div class="class-actions">
                        <a href="<?php echo e(route('classrooms.edit', $class->id)); ?>" class="btn-edit">Chỉnh sửa</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<script>
// Nút quay về
document.getElementById('back-button').addEventListener('click', function () {
    window.history.back();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/classrooms/index.blade.php ENDPATH**/ ?>