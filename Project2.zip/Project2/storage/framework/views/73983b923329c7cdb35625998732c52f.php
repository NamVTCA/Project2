<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đội Ngũ Giảng Dạy</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Teachers.css')); ?>"> </head>
<body>
    <div class="container teachers-page">
        <div class="back-to-dashboard">
            <button id="back-button" class="btn btn-secondary">← Quay về</button>
        </div>
        <h1 class="page-title">Đội Ngũ Giảng Dạy</h1>

        
        <h2 class="row-title">Nam</h2>
        <div class="row">
            <?php $__currentLoopData = $maleTeachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 teacher-card">
                    <div class="card">
                        <?php if($teacher->img): ?>
                            <img src="<?php echo e(asset('storage/' . $teacher->img)); ?>" class="card-img-top" alt="Ảnh của <?php echo e($teacher->name); ?>">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/250x250" class="card-img-top" alt="Ảnh của <?php echo e($teacher->name); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($teacher->name); ?></h5>
                            <p class="card-text"><strong>Email:</strong> <?php echo e($teacher->email); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <h2 class="row-title">Nữ</h2>
        <div class="row">
            <?php $__currentLoopData = $femaleTeachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 teacher-card">
                    <div class="card">
                        <?php if($teacher->img): ?>
                            <img src="<?php echo e(asset('storage/' . $teacher->img)); ?>" class="card-img-top" alt="Ảnh của <?php echo e($teacher->name); ?>">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/250x250" class="card-img-top" alt="Ảnh của <?php echo e($teacher->name); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($teacher->name); ?></h5>
                            <p class="card-text"><strong>Email:</strong> <?php echo e($teacher->email); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
<script>
// Nút quay về
document.getElementById('back-button').addEventListener('click', function () {
    window.history.back();
});
</script>
</html><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/link-to-teachers.blade.php ENDPATH**/ ?>