<div id="chat-box">
    <div id="messages"></div>
    <form id="send-message-form">
        <input type="hidden" name="classroom_id" value="CLASSROOM_ID">
        <input type="text" name="message" placeholder="Nhập tin nhắn...">
        <button type="submit">Gửi</button>
    </form>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    const classroomId = document.querySelector('[name="classroom_id"]').value;

function loadMessages() {
    fetch(`/messages/${classroomId}`)
        .then(response => response.json())
        .then(messages => {
            const messageBox = document.getElementById('messages');
            messageBox.innerHTML = '';
            messages.forEach(msg => {
                messageBox.innerHTML += `<div><b>${msg.sender_id}:</b> ${msg.message}</div>`;
            });
            messageBox.scrollTop = messageBox.scrollHeight;
        });
}

    document.getElementById('send-message-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('/messages/send', {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadMessages();
                    this.reset();
                } else {
                    alert('Gửi tin nhắn thất bại');
                }
            });
    });

    // Tải tin nhắn đầu tiên
    loadMessages();

    // Cập nhật tin nhắn mỗi 5 giây
    setInterval(loadMessages, 5000);
});

</script><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/message.blade.php ENDPATH**/ ?>