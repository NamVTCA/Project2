<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    

    <?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Quản lý người dùng</h2>
        
        <div class="mb-3">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Thêm người dùng mới</a>
            
            <div class="btn-group ml-2">
                <a href="<?php echo e(route('users.index', ['role' => 1])); ?>" 
                class="btn btn-<?php echo e($role == 1 ? 'secondary' : 'outline-secondary'); ?>">Teachers</a>
                <a href="<?php echo e(route('users.index', ['role' => 2])); ?>" 
                class="btn btn-<?php echo e($role == 2 ? 'secondary' : 'outline-secondary'); ?>">Parents</a>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('users.show', $user)); ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-primary btn-sm">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php $__env->stopSection(); ?>
  
</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/users/index.blade.php ENDPATH**/ ?>