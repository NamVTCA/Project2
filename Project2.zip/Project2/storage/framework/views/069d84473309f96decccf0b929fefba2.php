<?php $__env->startSection('content'); ?>

<main class="login-section">
    <link rel="stylesheet" href="<?php echo e(asset('css/Login.css')); ?>">
    <div class="logo">
        <img src="<?php echo e(asset('img/Login.png')); ?>" alt="Nursery PreSchool">
        <h1>Nursery PreSchool</h1>
    </div>
    <form class="login-form" action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="phone">Tài khoản (Email hoặc SĐT)</label>
        <input type="text" id="phone" name="phone" placeholder="*****">
        
        <label for="password">Mật khẩu</label>
        <input type="password" id="password" name="password" placeholder="******">
        
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <button type="submit" class="login-btn">Đăng nhập</button>
        
        <a href="<?php echo e(route('showfogot')); ?>" class="forgot-password">Quên Mật Khẩu</a>
        <p class="note">Lưu ý: <span>Hãy sử dụng tài khoản nhà trường cung cấp</span></p>
        
        <?php if(session('message')): ?>
            <div class="alert alert-success mt-2">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/login.blade.php ENDPATH**/ ?>