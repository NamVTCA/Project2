<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-center mb-4">Chỉnh sửa sự kiện</h2>
    <form method="POST" action="<?php echo e(route('events.update')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div id="events-container">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="event-item border rounded p-3 mb-4">
                <h5>Sự kiện #<?php echo e($index + 1); ?></h5>
                <div class="mb-3">
                    <label for="date_<?php echo e($index); ?>" class="form-label">Ngày</label>
                    <input type="text" name="events[<?php echo e($index); ?>][date]" id="date_<?php echo e($index); ?>" 
                        class="form-control" value="<?php echo e($event['date']); ?>">
                </div>
                <div class="mb-3">
                    <label for="title_<?php echo e($index); ?>" class="form-label">Tiêu đề</label>
                    <input type="text" name="events[<?php echo e($index); ?>][title]" id="title_<?php echo e($index); ?>" 
                        class="form-control" value="<?php echo e($event['title']); ?>">
                </div>
                <div class="mb-3">
                    <label for="description_<?php echo e($index); ?>" class="form-label">Mô tả</label>
                    <textarea name="events[<?php echo e($index); ?>][description]" id="description_<?php echo e($index); ?>" 
                        class="form-control" rows="3"><?php echo e($event['description']); ?></textarea>
                </div>
              <div class="mb-3">
    <label class="form-label">Hình ảnh</label>
    <div>
       <?php if(!empty($event['images'])): ?>
    <?php $__currentLoopData = $event['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-2">
       <img src="<?php echo e(Storage::url($image)); ?>" alt="Event image" class="img-thumbnail" style="width: 150px;">
        <input type="hidden" name="events[<?php echo e($index); ?>][existing_images][]" value="<?php echo e($image); ?>">
        <button type="button" class="btn btn-danger btn-sm remove-image" data-index="<?php echo e($index); ?>" data-key="<?php echo e($key); ?>">Xóa</button>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>Chưa có hình ảnh.</p>
<?php endif; ?>
<input type="file" name="events[<?php echo e($index); ?>][images][]" multiple class="form-control mt-2">

    </div>
    <button type="button" class="btn btn-sm btn-secondary add-image" data-index="<?php echo e($index); ?>">Thêm ảnh</button>
</div>
                <button type="button" class="btn btn-danger btn-sm remove-event">Xóa sự kiện</button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <button type="button" id="add-event" class="btn btn-success mb-4">Thêm sự kiện mới</button>
        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const eventsContainer = document.getElementById('events-container');
        const addEventBtn = document.getElementById('add-event');

        // Add new event form
        addEventBtn.addEventListener('click', () => {
            const eventCount = eventsContainer.children.length;
    const eventItem = `
<div class="event-item border rounded p-3 mb-4">
    <h5>Sự kiện mới</h5>
    <div class="mb-3">
        <label for="date_${eventCount}" class="form-label">Ngày</label>
        <input type="text" name="events[${eventCount}][date]" id="date_${eventCount}" class="form-control">
    </div>
    <div class="mb-3">
        <label for="title_${eventCount}" class="form-label">Tiêu đề</label>
        <input type="text" name="events[${eventCount}][title]" id="title_${eventCount}" class="form-control">
    </div>
    <div class="mb-3">
        <label for="description_${eventCount}" class="form-label">Mô tả</label>
        <textarea name="events[${eventCount}][description]" id="description_${eventCount}" class="form-control" rows="3"></textarea>
    </div>
    <div class="mb-3">
        <label class="form-label">Hình ảnh</label>
        <input type="file" name="events[${eventCount}][images][]" multiple class="form-control">
    </div>
    <button type="button" class="btn btn-danger btn-sm remove-event">Xóa sự kiện</button>
</div>
`;

eventsContainer.insertAdjacentHTML('beforeend', eventItem);

        });

        // Remove event form
        eventsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-event')) {
                e.target.closest('.event-item').remove();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/events_edit.blade.php ENDPATH**/ ?>