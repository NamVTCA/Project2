<?php $__env->startSection('title', 'Danh Sách Học Sinh trong Lớp'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/ChildClass.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="back-button">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
        <i class="fas fa-arrow-left"></i> Quay về
    </a>
</div>
<div class="container mt-4">
    <h2 class="text-center">Danh sách học sinh trong lớp</h2>

    <!-- Bộ lọc -->
    <form action="<?php echo e(route('childclass.index')); ?>" method="GET" class="form-inline mb-4">
        <div class="form-group mr-3">
            <label for="classroom_id" class="mr-2">Lọc theo lớp:</label>
            <select name="classroom_id" id="classroom_id" class="form-control">
                <option value="">Tất cả lớp</option>
                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classroom->id); ?>" 
                        <?php echo e(request('classroom_id') == $classroom->id ? 'selected' : ''); ?>>
                        <?php echo e($classroom->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Lọc</button>
    </form>

    <!-- Bảng danh sách học sinh -->
    <div class="table-responsive mt-4">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Học sinh</th>
                    <th>Lớp học</th>
                    <th>Ngày thêm</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $childclasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childclass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($childclass->child->name); ?></td>
                        <td><?php echo e($childclass->classroom->name); ?></td>
                        <td><?php echo e($childclass->created_at->format('d/m/Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('childclass.edit', ['child_id' => $childclass->child_id, 'classroom_id' => $childclass->classroom_id])); ?>" class="btn btn-warning btn-sm">Chỉnh sửa</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center">Không có học sinh nào trong lớp này.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
            // Nút quay về
            document.getElementById('back-button').addEventListener('click', function () {
            window.history.back();
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/childclassindex.blade.php ENDPATH**/ ?>