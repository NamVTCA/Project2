<?php $__env->startSection('title', 'Đặt Lại Mật Khẩu'); ?> <!-- Thay đổi tiêu đề trang -->

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/Fogotpassword.css')); ?>">
<main class="reset-password-page">
      <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php echo e($errors->first()); ?>

    </div>
<?php endif; ?>

    <div class="logo">
        <img src="<?php echo e(asset('img/Login.png')); ?>" alt="Nursery PreSchool">
        <h1>NURSERY PRESCHOOL</h1>
    </div>

    <form action="<?php echo e(route('otp')); ?>" method="get" class="send-otp-form">
        <?php echo csrf_field(); ?>
        <label for="phone">Số điện thoại:</label>
        <input type="text" id="phone" name="phone" placeholder="Nhập số điện thoại" required>
        <button type="submit" class="btn btn-primary">Gửi mã xác nhận</button>
    </form>

    <form action="<?php echo e(route('forgotpassword')); ?>" method="post" class="reset-password-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="phone" id="phone" value="<?php echo e(session('phone')); ?>">
        <label for="otp">Mã xác nhận</label>
        <input type="text" id="otp" name="otp" placeholder="Nhập mã xác nhận" required>
        <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="new-password">Mật khẩu mới</label>
        <input type="password" id="new_password" name="new_password" placeholder="Nhập mật khẩu mới" required>
       

        <label for="confirm-password">Nhập lại Mật khẩu mới</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Nhập lại mật khẩu mới" required>
      
        <button type="submit" class="reset-password-btn">Đặt lại mật khẩu</button>
        
        <div id="resetMessage"></div>
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/forgotpassword.blade.php ENDPATH**/ ?>