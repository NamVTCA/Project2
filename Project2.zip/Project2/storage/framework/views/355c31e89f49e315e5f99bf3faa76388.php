<?php $__env->startSection('content'); ?>
<div id="chat-app">
    <div class="users-list">
        <h3>Danh sách</h3>
        <ul>
            <?php if($role == 1): ?>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <strong>Lớp: <?php echo e($classroom->name); ?></strong>
                        <ul>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-id="<?php echo e($child->user->id); ?>" class="user-item">
                                    Phụ huynh: <?php echo e($child->user->name); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($role == 2): ?>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <strong>Con: <?php echo e($child->name); ?></strong> - Lớp: <?php echo e($child->classroom->name); ?>

                        <span data-id="<?php echo e($child->classroom->user->id); ?>" class="user-item">
                            Giáo viên: <?php echo e($child->classroom->user->name); ?>

                        </span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
    <div class="chat-box">
        <div id="chat-window"></div>
        <textarea id="message-input" placeholder="Nhập tin nhắn..."></textarea>
        <button id="send-button">Gửi</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let selectedUserId = null;

    document.querySelectorAll('.user-item').forEach(item => {
        item.addEventListener('click', function () {
            selectedUserId = this.getAttribute('data-id');
            document.getElementById('chat-window').innerHTML = '';
        });
    });

    document.getElementById('send-button').addEventListener('click', function () {
        const message = document.getElementById('message-input').value;

        if (!selectedUserId || !message.trim()) {
            alert('Chọn người nhận và nhập tin nhắn.');
            return;
        }

        fetch("<?php echo e(route('chat.send')); ?>", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            },
            body: JSON.stringify({ message, to_id: selectedUserId }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    const chatWindow = document.getElementById('chat-window');
                    chatWindow.innerHTML += `<div><strong>${data.from}:</strong> ${data.message}</div>`;
                }
            });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/message/view.blade.php ENDPATH**/ ?>