<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/Fogotpassword.css')); ?>">
<main class="reset-password-page">
    <div class="logo">
        <img src="<?php echo e(asset('img/Login.png')); ?>" alt="Nursery PreSchool">
        <h1>Nursery PreSchool</h1>
    </div>
    <?php if(session('success')): ?>
        <p class="text-success"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <form class="reset-password-form" method="POST" action="<?php echo e(route('reset.password')); ?>">
        <?php echo csrf_field(); ?>
        <label for="current_password">Mật Khẩu Cũ</label>
        <input type="password" id="current_password" name="current_password" placeholder="Nhập mật khẩu cũ">
        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="new_password">Mật khẩu mới</label>
        <input type="password" id="new_password" name="new_password" placeholder="Nhập mật khẩu mới">
        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="confirm_password">Nhập lại Mật khẩu mới</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Nhập lại mật khẩu mới">
        <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button type="submit" class="reset-password-btn">Xác Nhận</button>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/resetpassword.blade.php ENDPATH**/ ?>