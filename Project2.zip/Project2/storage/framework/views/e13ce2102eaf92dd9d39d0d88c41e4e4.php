<?php $__env->startSection('content'); ?>
<div class="profile-container">
    <div class="profile-header">
        <div class="profile-basic-info">
            <h1><?php echo e($classroom->name); ?></h1>
            <p>Teacher: <?php echo e($classroom->user ? $classroom->user->name : 'N/A'); ?></p>
            <p>Status: <?php echo e($classroom->status == 1 ? 'Active' : 'Inactive'); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/classrooms/show.blade.php ENDPATH**/ ?>