<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/ChildrenEdit.css')); ?>">
<div class="back-button">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
        <i class="fas fa-arrow-left"></i> Quay về
    </a>
</div>
<div class="edit-student-wrapper">
    <form action="<?php echo e(route('children.update', $child->id)); ?>" method="POST" enctype="multipart/form-data" id="childForm">
        <h2>Chỉnh sửa thông tin học sinh</h2>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label>Tên:</label>
            <input type="text" id="name" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $child->name ?? '')); ?>" required>
            <span class="invalid-feedback" id="name-error"></span>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label>Ngày sinh:</label>
            <input 
                type="date" 
                name="birthDate" 
                value="<?php echo e(old('birthDate', $child->birthDate ? (is_string($child->birthDate) ? $child->birthDate : $child->birthDate->format('Y-m-d')) : '')); ?>" 
                max="<?php echo e(date('Y-m-d')); ?>" 
                required>
                <?php $__errorArgs = ['birthDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>        

        <div>
            <label>Giới tính:</label>
            <select name="gender" required>
                <option value="1" <?php echo e(old('gender', $child->gender) == 1 ? 'selected' : ''); ?>>Nam</option>
                <option value="2" <?php echo e(old('gender', $child->gender) == 2 ? 'selected' : ''); ?>>Nữ</option>
            </select>
        </div>

        <div>
            <label>Phụ huynh:</label>
            <select name="user_id" required>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id', $child->user_id ?? '') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>                      
        </div>

        <div>
            <label>Trạng thái:</label>
            <select name="status" required>
                <option value="1" <?php echo e(old('status', $child->status) == 1 ? 'selected' : ''); ?>>Hoạt động</option>
                <option value="0" <?php echo e(old('status', $child->status) == 0 ? 'selected' : ''); ?>>Không hoạt động</option>
            </select>
        </div>

        <div>
            <label>Ảnh đại diện:</label>
            <?php if(isset($user) && $user->img): ?>
                <img src="<?php echo e(asset('storage/' . $child->img)); ?>" alt="Profile Image">
            <?php endif; ?>
            <input type="file" name="img" accept="image/*">
        </div>

        <button type="submit">Cập nhật thông tin học sinh</button>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() 
    {
        const nameInput = document.getElementById('name');
        const nameError = document.getElementById('name-error');

        nameInput.addEventListener('input', function() {
            const namePattern = /^[\p{L}\s]+$/u;
            if (!namePattern.test(this.value)) {
                nameError.textContent = 'Vui lòng nhập tên hợp lệ (chỉ chứa chữ cái và khoảng trắng)';
                this.classList.add('is-invalid');
            } else {
                nameError.textContent = '';
                this.classList.remove('is-invalid');
            }
        });
    })

        //     // Nút quay về
        //     document.getElementById('back-button').addEventListener('click', function () {
        //     window.history.back();
        // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/children/edit.blade.php ENDPATH**/ ?>