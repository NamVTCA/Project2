<?php $__env->startSection('content'); ?>
<div class="profile-container">
    <div class="profile-header">
        <div class="profile-image">
            <?php if($user->img): ?>
                <img src="<?php echo e(asset('storage/' . $user->img)); ?>" alt="Profile Image">
            <?php else: ?>
                <div class="default-avatar">
                    <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="profile-basic-info">
            <h1><?php echo e($user->name); ?></h1>
            <p class="role-badge <?php echo e($user->role == 1 ? 'teacher' : 'parent'); ?>">
                <?php echo e($user->role == 1 ? 'Giáo viên' : 'Phụ huynh'); ?>

            </p>
            <p class="status-badge <?php echo e($user->status == 1 ? 'active' : 'inactive'); ?>">
                <?php echo e($user->status == 1 ? 'Đang hoạt động' : 'Không hoạt động'); ?>

            </p>
        </div>
    </div>

    <div class="profile-content">
        <div class="info-section">
            <h2>Thông tin cá nhân</h2>
            <div class="info-grid">
                <div class="info-item">
                    <label>Email:</label>
                    <p><?php echo e($user->email); ?></p>
                </div>
                <div class="info-item">
                    <label>Số điện thoại:</label>
                    <p><?php echo e($user->phone); ?></p>
                </div>
                <div class="info-item">
                    <label>CMND/CCCD:</label>
                    <p><?php echo e($user->id_number); ?></p>
                </div>
                <div class="info-item">
                    <label>Giới tính:</label>
                    <p>
                        <?php switch($user->gender):
                            case ('male'): ?>
                                Nam
                                <?php break; ?>
                            <?php case ('female'): ?>
                                Nữ
                                <?php break; ?>
                            <?php default: ?>
                                Khác
                        <?php endswitch; ?>
                    </p>
                </div>
                <div class="info-item full-width">
                    <label>Địa chỉ:</label>
                    <p><?php echo e($user->address); ?></p>
                </div>
            </div>
        </div>

        <?php if($user->role == 1): ?>
            <div class="info-section">
                <h2>Thông tin giảng dạy</h2>
                <div class="classes-grid">
                    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="class-card">
                            <h3><?php echo e($classroom->name); ?></h3>
                            <div class="class-stats">
                                <div class="stat-item">
                                    <label>Số học sinh:</label>
                                    <p><?php echo e($classroom->children->count()); ?></p>
                                </div>
                                <div class="stat-item">
                                    <label>Trạng thái:</label>
                                    <p class="status-badge <?php echo e($classroom->status ? 'active' : 'inactive'); ?>">
                                        <?php echo e($classroom->status ? 'Đang hoạt động' : 'Không hoạt động'); ?>

                                    </p>
                                </div>
                            </div>
                            <a href="<?php echo e(route('classrooms.show', $classroom->id)); ?>" class="btn-view">
                                Xem chi tiết lớp học
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <div class="info-section">
                <h2>Thông tin học sinh</h2>
                <div class="children-grid">
                    <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="child-card">
                            <div class="child-image">
                                <?php if($child->img): ?>
                                    <img src="<?php echo e(asset('storage/' . $child->img)); ?>" alt="<?php echo e($child->name); ?>">
                                <?php else: ?>
                                    <div class="default-avatar">
                                        <?php echo e(strtoupper(substr($child->name, 0, 1))); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="child-info">
                                <h3><?php echo e($child->name); ?></h3>
                                <div class="info-item">
                                    <label>Ngày sinh:</label>
                                    <p><?php echo e(\Carbon\Carbon::parse($child->birthDate)->format('d/m/Y')); ?></p>
                                </div>
                                <div class="info-item">
                                    <label>Giới tính:</label>
                                    <p><?php echo e($child->gender == 1 ? 'Nam' : 'Nữ'); ?></p>
                                </div>
                                <?php if($child->classroom->first()): ?>
                                    <div class="info-item">
                                        <label>Lớp:</label>
                                        <p><?php echo e($child->classroom->first()->name); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('children.show', $child->id)); ?>" class="btn-view">
                                Xem chi tiết
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>

.classes-grid, .children-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.class-card, .child-card {
    background: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.child-image {
    width: 100px;
    height: 100px;
    margin: 0 auto 15px;
}

.child-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
}

.child-info {
    text-align: center;
}

.child-info h3 {
    margin: 0 0 15px 0;
    color: #333;
}

.class-stats {
    margin: 15px 0;
}

.btn-view {
    display: block;
    text-align: center;
    padding: 8px 15px;
    background: #007bff;
    color: white;
    border-radius: 5px;
    text-decoration: none;
    margin-top: 15px;
    transition: background 0.3s;
}

.btn-view:hover {
    background: #0056b3;
    color: white;
    text-decoration: none;
}

@media (max-width: 768px) {
    .classes-grid, .children-grid {
        grid-template-columns: 1fr;
    }
    
    .profile-header {
        flex-direction: column;
        text-align: center;
    }
    
    .profile-image {
        margin: 0 0 20px 0;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/users/profile.blade.php ENDPATH**/ ?>