<?php $__env->startSection('content'); ?>
<div class="container">
    <link rel="stylesheet" href="<?php echo e(asset('css/ScheduleIndex.css')); ?>">
    <h1>Tạo Lịch học</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
     
    <form action="<?php echo e(route('schedule.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <!-- Chọn lớp học -->
        <div class="form-group">
            <label for="classroom_id">Lớp học</label>
            <select name="classroom_id" id="classroom_id" class="form-control" required>
                <option value="">-- Chọn lớp học --</option>
                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <!-- Chọn môn học -->
        <div class="form-group">
            <label for="subject_id">Môn học</label>
            <select name="subject_id" id="subject_id" class="form-control" required>
                <option value="">-- Chọn môn học --</option>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <!-- Chọn ngày học -->
        <div class="form-group">
            <label for="date">Ngày học</label>
            <input type="date" name="date" id="date" class="form-control" required>
        </div>
        <!-- Chọn tiết học -->
        <div class="form-group">
            <label for="lesson">Tiết học</label>
            <select name="lesson" id="lesson" class="form-control" required>
                <option value="">-- Chọn tiết học --</option>
                    <option value="Tiết 1 (7h30 - 8h05)">Tiết 1 (7h30 - 8h05)</option>
                    <option value="Tiết 2 (8h15 - 8h50)">Tiết 2 (8h15 - 8h50)</option>
                    <option value="Tiết 3 (9h00 - 9h35)">Tiết 3 (9h00 - 9h35)</option>
                    <option value="Tiết 4 (9h45 - 10h15)">Tiết 4 (9h45 - 10h20)</option>
                    <option value="Tiết 5 (10h30 - 11h15)">Tiết 5 (10h30 - 11h15)</option>
                    <option value="Tiết 6 (13h30 - 14h05)">Tiết 6 (13h30 - 14h05)</option>
                    <option value="Tiết 7 (14h15 - 14h50)">Tiết 7 (14h15 - 14h50)</option>
                    <option value="Tiết 8 (15h00 - 15h35)">Tiết 8 (15h00 - 15h35)</option>
                    <option value="Tiết 9 (15h45 - 16h20)">Tiết 9 (15h45 - 16h20)</option>
                    <option value="Tiết 10 (16h30 - 17h05)">Tiết 10 (16h30 - 17h05)</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Tạo Lịch học</button>
        <a href="<?php echo e(route('subjects.index')); ?>" class="btn btn-glow">Thêm Môn Học</a>
        <a href="<?php echo e(route('schedule.show')); ?>" class="btn btn-glow">Xem Lịch Học</a>    
    </form>
   <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php echo e($errors->first()); ?>

    </div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/schedule/index.blade.php ENDPATH**/ ?>