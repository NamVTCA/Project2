<?php $__env->startSection('content'); ?>
<div>
    <link rel="stylesheet" href="<?php echo e(asset('css/ChildrenCreation.css')); ?>">
    <div class="back-button">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Quay về
        </a>
    </div>
    <h2>Tạo học sinh mới</h2>

    <form action="<?php echo e(route('children.store')); ?>" method="POST" enctype="multipart/form-data" id="childForm">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom: 15px;">
            <label>Tên:</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" required pattern="^[\p{L}\s]+$" title="Tên chỉ được chứa chữ cái và khoảng trắng" oninput="validateName(this)">
            <span class="error-message" style="color: rgb(255, 255, 255); display: none;">Vui lòng nhập tên hợp lệ (chỉ chứa chữ cái và khoảng trắng).</span>
        </div>

        <div style="margin-bottom: 15px;">
            <label>Ngày sinh:</label>
            <input type="date" name="birthDate" value="<?php echo e(old('birthDate')); ?>" max="<?php echo e(date('Y-m-d')); ?>" required>
            <?php $__errorArgs = ['birthDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div style="margin-bottom: 15px;">
            <label>Giới tính:</label>
            <select name="gender" required>
                <option value="1" <?php echo e(old('gender') == 1 ? 'selected' : ''); ?>>Nam</option>
                <option value="2" <?php echo e(old('gender') == 2 ? 'selected' : ''); ?>>Nữ</option>
            </select>
        </div>

        <div style="margin-bottom: 15px;">
            <label>Phụ huynh:</label>
            <select name="user_id" required>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id', $child->user_id ?? '') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>                    
        </div>

        <div style="margin-bottom: 15px;">
            <label>Trạng thái:</label>
            <select name="status" required>
                <option value="1" <?php echo e(old('status') == 1 ? 'selected' : ''); ?>>Hoạt động</option>
                <option value="0" <?php echo e(old('status') == 0 ? 'selected' : ''); ?>>Không hoạt động</option>
            </select>
        </div>

        <div style="margin-bottom: 15px;">
            <label>Ảnh đại diện:</label>
            <?php if(isset($user) && $user->img): ?>
                <div style="margin: 10px 0;">
                    <img src="<?php echo e(asset('storage/' . $user->img)); ?>" alt="Profile Image" style="max-width: 200px;">
                </div>
            <?php endif; ?>
            <input type="file" name="img" accept="image/jpeg,image/png,image/jpg">
        </div>        

        <button type="submit">Tạo học sinh</button>
    </form>
</div>

<script>
    function validateName(input) {
        const pattern = /^[\p{L}\s]+$/u; 
        const errorMessage = input.nextElementSibling;
        if (!pattern.test(input.value)) {
            errorMessage.style.display = 'block'; 
            input.setCustomValidity('Tên chỉ được chứa chữ cái và khoảng trắng');
        } else {
            errorMessage.style.display = 'none'; 
            input.setCustomValidity(''); 
        }
    }
            // Nút quay về
            document.getElementById('back-button').addEventListener('click', function () {
            window.history.back();
        });
    </script>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/children/create.blade.php ENDPATH**/ ?>