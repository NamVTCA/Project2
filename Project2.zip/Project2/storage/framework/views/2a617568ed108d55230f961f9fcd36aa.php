<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/Timetable.css')); ?>">
<div class="back-button">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
        <i class="fas fa-arrow-left"></i> Quay về
    </a>
</div>
<main class="timetable-container">
    <h1 class="page-title">Quản Lý Học Kỳ</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="semester-list">
        <h2>Danh Sách Học Kỳ</h2>
        <?php if(count($semesters) > 0): ?>
            <ul>
                <?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <span><?php echo e($semester); ?></span>
                        <div class="actions">
                            <form action="<?php echo e(route('timetable.deleteSemester', ['semester' => $semester])); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="delete-btn" onclick="return confirm('Bạn có chắc muốn xóa học kỳ này?')">Xóa</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>Chưa có học kỳ nào được tạo.</p>
        <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/manage.blade.php ENDPATH**/ ?>