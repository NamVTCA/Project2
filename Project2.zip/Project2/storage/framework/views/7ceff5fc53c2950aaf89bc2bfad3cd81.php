<?php $__env->startSection('content'); ?>
<div class="subjects-page">
    <link rel="stylesheet" href="<?php echo e(asset('css/Subjects.css')); ?>">
    <h1>Danh sách Môn học</h1>

    <!-- Hiển thị thông báo -->
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <!-- Form thêm mới -->
    <form action="<?php echo e(route('subjects.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Tên môn học" required>
        <button type="submit">Thêm</button>
    </form>

    <h2>Danh sách:</h2>
    <ul>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($subject->name); ?>

                <!-- Nút chỉnh sửa -->
                <form action="<?php echo e(route('subjects.update', $subject->id)); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="text" name="name" value="<?php echo e($subject->name); ?>" required>
                    <button type="submit">Cập nhật</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/subject/index.blade.php ENDPATH**/ ?>