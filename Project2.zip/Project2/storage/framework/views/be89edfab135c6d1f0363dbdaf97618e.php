<?php $__env->startSection('title', 'CameraCreate'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/CameraCreate.css')); ?>">
<div class="back-to-dashboard">
    <button id="back-button" class="btn btn-secondary">← Quay về</button>
</div>
<div class="container-camera-create">
    <h1>Thêm camera</h1>
    <form action="<?php echo e(route('cameras.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Tên camera:</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="stream_url">Stream URL:</label>
            <input type="url" name="stream_url" id="stream_url" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Thêm camera</button>
    </form>
</div>

<script>
            // Nút quay về
            document.getElementById('back-button').addEventListener('click', function () {
            window.history.back();
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/camdemo/create.blade.php ENDPATH**/ ?>