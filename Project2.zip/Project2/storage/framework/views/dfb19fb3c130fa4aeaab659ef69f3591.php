<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/TuitionManagement.css')); ?>">
<div class="hoc-phi-container">
    <div class="back-button">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Quay về
        </a>
    </div>
    <h1>Quản Lý Học Phí</h1>

    <div class="actions">
        <a href="<?php echo e(route('tuition.create')); ?>" class="btn">Tạo Học Phí</a>
    </div>

    <form method="GET" action="<?php echo e(route('tuition.index')); ?>">
        <div class="form-group">
            <label for="classroom_id">Chọn Lớp</label>
            <select name="classroom_id" id="classroom_id" class="form-control" onchange="this.form.submit()">
                <option value="">-- Chọn lớp --</option>
                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classroom->id); ?>" <?php echo e(request('classroom_id') == $classroom->id ? 'selected' : ''); ?>>
                        <?php echo e($classroom->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="children_id">Chọn Học Sinh</label>
            <select name="children_id" id="children_id" class="form-control" onchange="this.form.submit()">
                <option value="">-- Chọn học sinh --</option>
                <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($child->id); ?>" <?php echo e(request('children_id') == $child->id ? 'selected' : ''); ?>>
                        <?php echo e($child->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </form>

    <?php if($selectedChild): ?>
        <div class="child-info">
            <h3>Thông Tin Trẻ</h3>
            <p><strong>Tên Phụ Huynh:</strong> <?php echo e($selectedChild->user->name); ?></p>
            <p><strong>Ngày Sinh:</strong> <?php echo e($selectedChild->birthDate); ?></p>
            <p><strong>Giới Tính:</strong> <?php echo e($selectedChild->gender == 1 ? 'Nam' : 'Nữ'); ?></p>
        </div>

        <table class="tuition-table">
            <thead>
                <tr>
                    <th>Kỳ Học</th>
                    <th>Trạng Thái</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $selectedChild->tuition; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tuition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tuition->semester); ?></td>
                        <td><?php echo e($tuition->status ? 'Đã Đóng' : 'Chưa Đóng'); ?></td>
                       
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
</div>
<script>
            // Nút quay về
            document.getElementById('back-button').addEventListener('click', function () {
            window.history.back();
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/tuitionmanagement.blade.php ENDPATH**/ ?>