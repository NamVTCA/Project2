<?php $__env->startSection('content'); ?>
<div class="content-section">
    <section class="event-section py-5">
        <div class="container">
            <div class="section-header text-center mb-5">
                <h2 class="text-primary fw-bold">Sự Kiện Trường Chúng Tôi</h2>
            </div>
            <div class="events-timeline">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="event-card">
                    <div class="event-header">
                        <div class="swiper mySwiper">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $event['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <img src="<?php echo e(asset($image)); ?>" alt="<?php echo e($event['title']); ?>">
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="swiper-pagination"></div>
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                        </div>
                    </div>
                    <div class="event-content">
                        <div class="event-date"><?php echo e($event['date']); ?></div>
                        <h3><?php echo e($event['title']); ?></h3>
                        <p class="event-description"><?php echo e($event['description']); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/events/index.blade.php ENDPATH**/ ?>