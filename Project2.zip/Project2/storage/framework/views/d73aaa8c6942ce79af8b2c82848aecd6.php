<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
</head>
<body>
    <!-- Header Section -->
    <header class="bg-light py-3 shadow-sm">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="title">NURSERY PRESCHOOL</div>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('index')); ?>">Trang chủ</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('event')); ?>">Sự kiện</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('education')); ?>">Giáo dục</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('rules')); ?>">Nội quy</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('feedback')); ?>">Phản hồi</a></li>
                        <li class="nav-item">
                            <?php if(Auth::check()): ?>
                                <!-- Hiển thị "Đăng Xuất" nếu người dùng đã đăng nhập -->
                                <a class="nav-link" href="<?php echo e(route('logout')); ?>" 
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    Đăng xuất
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            <?php else: ?>
                                <!-- Hiển thị "Đăng Nhập" nếu người dùng chưa đăng nhập -->
                                <a class="nav-link" href="<?php echo e(route('login')); ?>">Đăng nhập</a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <main class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- Bootstrap JS (Required for navbar-toggler) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>