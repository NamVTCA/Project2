
<?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/layouts/app.blade.php ENDPATH**/ ?>