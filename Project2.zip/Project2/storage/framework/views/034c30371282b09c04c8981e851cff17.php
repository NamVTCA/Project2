<?php $__env->startSection('title', 'Chỉnh Sửa Học Sinh trong Lớp'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/ChildClass.css')); ?>">
<div class="back-button">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
        <i class="fas fa-arrow-left"></i> Quay về
    </a>
</div>
<div class="container mt-4">
    <h2 class="text-center">Chỉnh sửa học sinh trong lớp</h2>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    
    
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="alert alert-info"><?php echo e(session('info')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('childclass.update', ['child_id' => $childclass->child_id, 'classroom_id' => $childclass->classroom_id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="form-group mt-3">
            <label for="classroom_id">Lớp học</label>
            <select name="classroom_id" id="classroom_id" class="form-control" required>
                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classroom->id); ?>" <?php echo e($childclass->classroom_id == $classroom->id ? 'selected' : ''); ?>>
                        <?php echo e($classroom->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-4">Cập nhật</button>
    </form>
</div>

<script>
            // Nút quay về
            document.getElementById('back-button').addEventListener('click', function () {
            window.history.back();
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/childclassedit.blade.php ENDPATH**/ ?>