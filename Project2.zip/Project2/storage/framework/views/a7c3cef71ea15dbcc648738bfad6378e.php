<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/FacilitiesCreation.css')); ?>">
<div class="facility-edit-page">
    <h2>Chỉnh sửa cơ sở vật chất</h2>
    <div class="back-button">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Quay về
        </a>
    </div>
    <?php if($errors->any()): ?>
        <div class="error-list">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('facility_management.update', ['total' => $total->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Tên cơ sở vật chất:</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', $total->name)); ?>" required>
        </div>

        <div id="dentail-details">
            <h5>Chi tiết cơ sở vật chất</h5>
            <?php $__currentLoopData = $total->dentail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dentail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dentail-detail" id="dentail-<?php echo e($dentail->id); ?>">
                    <div class="form-group">
                        <label for="dentail[<?php echo e($index); ?>][name]">Tên chi tiết</label>
                        <input type="text" name="dentail[<?php echo e($index); ?>][name]" class="form-control" value="<?php echo e(old('dentail.' . $index . '.name', $dentail->name)); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="dentail[<?php echo e($index); ?>][quantity]">Số lượng</label>
                        <input type="number" name="dentail[<?php echo e($index); ?>][quantity]" class="form-control" value="<?php echo e(old('dentail.' . $index . '.quantity', $dentail->quantity)); ?>" required>
                    </div>
                    <button type="button" class="btn btn-danger remove-dentail" data-id="<?php echo e($dentail->id); ?>">Xóa</button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <input type="hidden" name="deleted_dentails" id="deleted-dentails">

        <button type="button" id="add-dentail" class="btn btn-secondary">Thêm chi tiết</button>
        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>
</div>

<script>
    let dentailIndex = <?php echo e(count($total->dentail)); ?>;

    document.getElementById('add-dentail').addEventListener('click', function () {
        const dentailDetails = document.getElementById('dentail-details');

        const newDetail = `
            <div class="dentail-detail">
                <div class="form-group">
                    <label for="dentail[${dentailIndex}][name]">Tên Chi Tiết</label>
                    <input type="text" name="dentail[${dentailIndex}][name]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="dentail[${dentailIndex}][quantity]">Số Lượng</label>
                    <input type="number" name="dentail[${dentailIndex}][quantity]" class="form-control" required>
                </div>
                <button type="button" class="btn btn-danger remove-dentail">Xóa</button>
            </div>
        `;
        dentailDetails.insertAdjacentHTML('beforeend', newDetail);
        dentailIndex++;
    });

    document.addEventListener('click', function (e) {
        if (e.target && e.target.classList.contains('remove-dentail')) {
            const dentailId = e.target.getAttribute('data-id');
            if (dentailId) {
                const deletedDentails = document.getElementById('deleted-dentails');
                let deletedIds = deletedDentails.value ? deletedDentails.value.split(',') : [];
                deletedIds.push(dentailId);
                deletedDentails.value = deletedIds.join(',');
            }
            e.target.parentElement.remove();
        }
    });

            // Nút quay về
            document.getElementById('back-button').addEventListener('click', function () {
            window.history.back();
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/facilities/edit.blade.php ENDPATH**/ ?>