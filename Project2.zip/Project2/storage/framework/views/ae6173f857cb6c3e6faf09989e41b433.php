<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa Môn học</title>
</head>
<body>
    <h1>Sửa Môn học</h1>

    <!-- Hiển thị lỗi nếu có -->
    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form sửa môn học -->
    <form action="<?php echo e(route('subjects.update', $subject->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="text" name="name" value="<?php echo e(old('name', $subject->name)); ?>" required>
        <button type="submit">Cập nhật</button>
    </form>

    <a href="<?php echo e(route('subjects.index')); ?>">Quay lại danh sách</a>
</body>
</html>
<?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/subjects/edit.blade.php ENDPATH**/ ?>