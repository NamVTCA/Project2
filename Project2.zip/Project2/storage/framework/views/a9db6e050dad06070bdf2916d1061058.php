<?php $__env->startSection('title', 'Danh sách Camera'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/CamIndex.css')); ?>">

<div class="container camera-page">
    <!-- Nút quay về -->
    <div class="back-to-dashboard">
        <button id="back-button" class="btn btn-secondary">← Quay về</button>
    </div>

    <!-- Tiêu đề -->
    <h1>Danh sách camera</h1>

    <!-- Danh sách camera -->
    <div class="row">
        <?php $__currentLoopData = $cameras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 camera-card">
            <!-- Tên camera -->
            <h3 class="camera-name"><?php echo e($camera->name); ?></h3>
        
            <!-- Hiển thị video -->
            <div class="camera-stream">
                <iframe src="<?php echo e($camera->stream_url); ?>" frameborder="0" allowfullscreen></iframe>
            </div>     
                <a href="<?php echo e($camera->stream_url); ?>" target="_blank" class="btn btn-primary">Xem Toàn Bộ</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script>
    // Nút quay về
    document.getElementById('back-button').addEventListener('click', function () {
        window.history.back();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/camdemo/camuser.blade.php ENDPATH**/ ?>