<?php $__env->startSection('title', 'Danh sách phản hồi'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="back-button">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Quay về
        </a>
    </div>
    <link rel="stylesheet" href="<?php echo e(asset('css/FeedbackList.css')); ?>">
    <h2 class="text-center page-title">Danh sách phản hồi</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($feedbacks->isEmpty()): ?>
        <div class="alert alert-warning">Không có phản hồi nào!</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Số thứ tự</th>
                        <th>Tên người gửi</th>
                        <th>Email</th>
                        <th>Nội dung</th>
                        <th>Ngày gửi</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($feedback->name); ?></td>
                            <td><?php echo e($feedback->email); ?></td>
                            <td><?php echo e($feedback->content); ?></td>
                            <td><?php echo e($feedback->created_at->format('d/m/Y H:i')); ?></td>
                            <td>
                                <form action="<?php echo e(route('feedback.destroy', $feedback->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Xóa</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>


<script>
document.getElementById('back-button').addEventListener('click', function () {
    window.history.back();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/users/feedbackList.blade.php ENDPATH**/ ?>