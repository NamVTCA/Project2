<!-- resources/views/tuitionmanagement.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Học Phí</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/TuitionManagement.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Quản Lý Học Phí</h1>

        <div class="actions">
            <a href="<?php echo e(route('tuition.create')); ?>" class="btn">Tạo Học Phí</a>
        </div>
        <div class="form-group">
    <label for="children_id">học sinh</label>
    <form method="GET" action="<?php echo e(route('tuition.index')); ?>">
        <select name="children_id" id="children_id" class="form-control" onchange="this.form.submit()">
            <option value="">-- Chọn học sinh --</option>
            <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($child->id); ?>" 
                        <?php echo e(request('children_id') == $child->id ? 'selected' : ''); ?>>
                    <?php echo e($child->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>
</div>

        <table class="tuition-table">
          
        </table>
    </div> 

    <!-- Nếu có thông báo thành công -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

</body>
</html>
<?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/TuitionManagement.blade.php ENDPATH**/ ?>