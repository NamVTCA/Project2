<?php $__env->startSection('content'); ?>
<div class="content-section">
    <section class="event-management py-5">
        <div class="container">
            <div class="section-header text-center mb-5">
                <h2 class="text-primary fw-bold">Quản Lý Sự Kiện</h2>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('events.update')); ?>">
                <?php echo csrf_field(); ?>
                <div id="event-forms">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="event-form mb-4 border p-4 rounded">
                        <h5 class="text-secondary">Sự kiện #<?php echo e($event['id']); ?></h5>

                        <input type="hidden" name="events[<?php echo e($loop->index); ?>][id]" value="<?php echo e($event['id']); ?>">

                        <div class="mb-3">
                            <label for="title-<?php echo e($loop->index); ?>" class="form-label">Tiêu đề</label>
                            <input type="text" name="events[<?php echo e($loop->index); ?>][title]" class="form-control" 
                                   id="title-<?php echo e($loop->index); ?>" value="<?php echo e($event['title']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="date-<?php echo e($loop->index); ?>" class="form-label">Ngày</label>
                            <input type="date" name="events[<?php echo e($loop->index); ?>][date]" class="form-control" 
                                   id="date-<?php echo e($loop->index); ?>" value="<?php echo e($event['date']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="description-<?php echo e($loop->index); ?>" class="form-label">Mô tả</label>
                            <textarea name="events[<?php echo e($loop->index); ?>][description]" class="form-control" 
                                      id="description-<?php echo e($loop->index); ?>" rows="3"><?php echo e($event['description']); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Hình ảnh</label>
                            <div class="image-inputs">
                                <?php $__currentLoopData = $event['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageIndex => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex align-items-center mb-2">
                                    <input type="text" name="events[<?php echo e($loop->parent->index); ?>][images][<?php echo e($imageIndex); ?>]" 
                                           class="form-control me-2" value="<?php echo e($image); ?>">
                                    <button type="button" class="btn btn-danger btn-sm remove-image">Xóa</button>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn btn-primary btn-sm add-image">Thêm hình ảnh</button>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-success">Cập Nhật</button>
                </div>
            </form>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    // Add new image input
    document.querySelectorAll('.add-image').forEach(button => {
        button.addEventListener('click', function () {
            const container = this.closest('.mb-3').querySelector('.image-inputs');
            const newInput = document.createElement('div');
            newInput.classList.add('d-flex', 'align-items-center', 'mb-2');
            newInput.innerHTML = `
                <input type="text" name="" class="form-control me-2" placeholder="Đường dẫn hình ảnh">
                <button type="button" class="btn btn-danger btn-sm remove-image">Xóa</button>
            `;
            container.appendChild(newInput);
            updateImageInputNames(container);
        });
    });

    // Remove image input
    document.querySelectorAll('.image-inputs').forEach(container => {
        container.addEventListener('click', function (e) {
            if (e.target.classList.contains('remove-image')) {
                e.target.closest('.d-flex').remove();
                updateImageInputNames(container);
            }
        });
    });

    // Update image input names dynamically
    function updateImageInputNames(container) {
        const eventIndex = container.closest('.event-form').querySelector('input[type="hidden"]').name.match(/\[(\d+)\]/)[1];
        container.querySelectorAll('.d-flex').forEach((inputGroup, index) => {
            inputGroup.querySelector('input').setAttribute('name', 
                `events[${eventIndex}][images][${index}]`);
        });
    }
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/events/manage.blade.php ENDPATH**/ ?>