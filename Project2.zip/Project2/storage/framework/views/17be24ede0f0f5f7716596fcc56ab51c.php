<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Tài Khoản</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AccountManagement.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Quản Lý Tài Khoản</h1>

        <div class="actions">
            <a href="<?php echo e(route('accountcreation')); ?>" class="btn">Thêm Tài Khoản</a>
        </div>

        <table class="account-table">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Tên Đầy Đủ</th>
                    <th>Email</th>
                    <th>CCCD</th>
                    <th>Trạng Thái</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <!-- Duyệt qua danh sách tài khoản -->
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($account->name); ?></td>
                        <td><?php echo e($account->email); ?></td>
                        <td><?php echo e($account->id_number); ?></td>
                        <td><?php echo e($account->status ? 'Hoạt Động' : 'Không Hoạt Động'); ?></td>
                        <td>
                            <a href="<?php echo e(route('account.edit', $account->id)); ?>" class="btn btn-edit">Sửa</a>
                            <form action="<?php echo e(route('account.delete', $account->id)); ?>" method="POST" class="inline-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-delete">Xóa</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/accountmanagement.blade.php ENDPATH**/ ?>