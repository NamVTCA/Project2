<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/Timetable.css')); ?>">
<div class="back-button">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
        <i class="fas fa-arrow-left"></i> Quay về
    </a>
</div>
<main class="timetable-container">  
    <h1 class="page-title">Chỉnh Sửa Thời Khóa Biểu</h1>
    <div class="timetable">
        <form id="timetable-form" action="<?php echo e(route('timetable.save')); ?>" method="POST" onsubmit="return validateForm()">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="semester">Học kỳ:</label>
                <input type="text" id="semester" name="semester" placeholder="Nhập học kỳ (Ngày bắt đầu - Ngày kết thúc) Ví Dụ: Học kỳ 1(13/12/2024 - 13/4/2025)" required>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Tiết</th>
                        <th>Thời gian</th>
                        <th>Thứ 2</th>
                        <th>Thứ 3</th>
                        <th>Thứ 4</th>
                        <th>Thứ 5</th>
                        <th>Thứ 6</th>
                        <th>Thứ 7</th>
                    </tr>
                </thead>
              <tbody>
    <?php
        $times = [
            '1' => '7:30 - 8:05',
            '2' => '8:15 - 8:50',
            'break_1' => '9:00 - 9:35 Giờ ra chơi buổi sáng', // Giờ ra chơi buổi sáng
            '3' => '9:45 - 10:15',
            '4' => '10:30 - 11:15',
            'break_2' => 'Nghỉ nửa buổi', // Nghỉ nửa buổi
            '5' => '13:30 - 14:05',
            '6' => '14:15 - 14:50',
            'break_3' => '15:00 - 15:35 Giờ ra chơi buổi chiều', // Giờ ra chơi buổi chiều
            '7' => '15:45 - 16:20',
            '8' => '16:30 - 17:05'
        ];
    ?>

    <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(str_contains($period, 'break')): ?>
            <!-- Hàng dành cho giờ ra chơi hoặc nghỉ trưa -->
            <tr class="break-row">
                <td colspan="8" class="text-center"><?php echo e($time); ?></td>
            </tr>
        <?php else: ?>
            <!-- Hàng dành cho các tiết học -->
            <tr>
                <th>Tiết <?php echo e(is_numeric($period) ? $period : ''); ?></th>
                <td><?php echo e($time); ?></td>
                <?php for($day = 2; $day <= 7; $day++): ?>
                    <td>
                        <input 
                            type="text" 
                            class="t<?php echo e($day); ?> p<?php echo e($period); ?>" 
                            name="schedule[t<?php echo e($day); ?>][p<?php echo e($period); ?>]" 
                            placeholder="Nhập Môn" 
                            required>
                    </td>
                <?php endfor; ?>
            </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

            </table>
            <button type="submit" class="save-btn">Lưu Thời Khóa Biểu</button>
            <a href="<?php echo e(route('timetable.view')); ?>" class="btn btn-light btn-sm">Xem Lịch Học</a>
            <a href="<?php echo e(route('timetable.manage')); ?>" class="btn btn-light btn-sm">Xem Học Kỳ</a>
        </form>
        <?php if(session('message')): ?>
            <div class="alert alert-success mt-2">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
</main>

<script>
    function validateForm() {
        const inputs = document.querySelectorAll('#timetable-form input[type="text"]');
        for (let input of inputs) {
            if (!input.value.trim()) {
                alert('Vui lòng điền đầy đủ tất cả các trường.');
                input.focus();
                return false;
            }
        }
        return true;
    }

            // Nút quay về
            document.getElementById('back-button').addEventListener('click', function () {
            window.history.back();
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/timetable.blade.php ENDPATH**/ ?>