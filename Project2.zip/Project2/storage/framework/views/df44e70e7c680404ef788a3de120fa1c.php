<?php $__env->startSection('content'); ?>
<div class="profile-container">
    <div class="profile-header">
        <div class="profile-image">
            <?php if($child->user && $child->user->img): ?>
                <?php
                    $imagePath = 'storage/' . $child->user->img;
                ?>
                <img src="<?php echo e(asset($imagePath)); ?>" alt="Profile Image" style="max-width: 200px;">
                <p>Đường dẫn ảnh: <?php echo e(asset($imagePath)); ?></p> <!-- Hiển thị đường dẫn để kiểm tra -->
            <?php else: ?>
                <div class="default-avatar">
                    <?php echo e(strtoupper(substr($child->user ? $child->user->name : 'N/A', 0, 1))); ?>

                </div>
            <?php endif; ?>
        </div>                 
        <div class="profile-basic-info">
            <h1><?php echo e($child->name); ?></h1>
            <p>Ngày sinh: <?php echo e(\Carbon\Carbon::parse($child->birthDate)->format('d/m/Y')); ?></p>
            <p>Giới tính: <?php echo e($child->gender == 1 ? 'Nam' : 'Nữ'); ?></p>
            <p>Phụ huynh: <?php echo e($child->user ? $child->user->name : 'N/A'); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/children/show.blade.php ENDPATH**/ ?>