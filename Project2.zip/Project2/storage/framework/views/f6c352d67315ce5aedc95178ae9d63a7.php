<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #000; padding: 8px; text-align: center; }
        .break-row td { background-color: #f0f0f0; font-style: italic; }
    </style>
</head>
<body>
    <h1 style="text-align: center;">Thời Khóa Biểu - Học Kỳ <?php echo e($selectedSemester); ?></h1>
    <table>
        <thead>
            <tr>
                <th>Tiết</th>
                <th>Thời gian</th>
                <th>Thứ 2</th>
                <th>Thứ 3</th>
                <th>Thứ 4</th>
                <th>Thứ 5</th>
                <th>Thứ 6</th>
                <th>Thứ 7</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(str_contains($period, 'break')): ?>
                    <tr class="break-row">
                        <td colspan="8"><?php echo e($time); ?></td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td>Tiết <?php echo e(is_numeric($period) ? $period : ''); ?></td>
                        <td><?php echo e($time); ?></td>
                        <?php for($day = 2; $day <= 7; $day++): ?>
                            <td><?php echo e($schedule["t$day"]["p$period"] ?? ''); ?></td>
                        <?php endfor; ?>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/schedule/pdf.blade.php ENDPATH**/ ?>