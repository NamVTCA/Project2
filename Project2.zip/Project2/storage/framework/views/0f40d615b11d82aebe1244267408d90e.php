<link rel="stylesheet" href="<?php echo e(asset('css/FacilitiesIndex.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="facilities-index-page">
    <div class="back-button">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Quay về
        </a>
    </div>
    <h2>Quản lý cơ sở vật chất</h2>
    <a href="<?php echo e(route('facility_management.create')); ?>" class="btn btn-primary">Thêm Cơ Sở Vật Chất Mới</a>

    <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="total-facility">
            <h3><?php echo e($total->name); ?></h3>
            <a href="<?php echo e(route('facility_management.edit', ['total' => $total->id])); ?>" class="btn btn-warning">Chỉnh Sửa</a>
            <form action="<?php echo e(route('facility_management.destroy', ['total' => $total->id])); ?>" method="POST" style="display:inline;">
                
            </form>
            
            <h5>Chi Tiết Cơ Sở Vật Chất</h5>
            <ul>
                <?php $__currentLoopData = $total->dentail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dentail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($dentail->name); ?> - Số lượng: <?php echo e($dentail->quantity); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>        // Nút quay về
    document.getElementById('back-button').addEventListener('click', function () {
        window.history.back();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/admin/facilities/index.blade.php ENDPATH**/ ?>