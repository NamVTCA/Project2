<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý môn học</title>
</head>
<body>
    <h1>Danh sách Môn học</h1>

    <!-- Hiển thị thông báo -->
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <!-- Form thêm mới -->
    <form action="<?php echo e(route('subjects.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Tên môn học" value="<?php echo e(old('name')); ?>" required>
        <button type="submit">Thêm</button>
    </form>

    <!-- Hiển thị lỗi nếu có -->
    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <h2>Danh sách:</h2>
    <ul>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($subject->name); ?>


                <!-- Nút sửa -->
                <a href="<?php echo e(route('subjects.edit', $subject->id)); ?>">Sửa</a>

                <!-- Nút xóa -->
                <form action="<?php echo e(route('subjects.destroy', $subject->id)); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\Users\THIS PC\Downloads\test\Project2\Project2\resources\views/subjects/index.blade.php ENDPATH**/ ?>